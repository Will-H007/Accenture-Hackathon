import plotly.express as px
from plotly.subplots import make_subplots
import plotly.graph_objects as go
import pandas as pd



import matplotlib.pyplot as plt
data = pd.read_csv("historicalDataFrame.csv")
df = pd.DataFrame(data)
pd.options.plotting.backend = "plotly"
fig = make_subplots(rows=1, cols=2)

SOLAR_PRICE = 1.4
DIESEL_PRICE = 0.2
Total_usage_column = df["Supply Pump 1 Power (KWh)"]/4 + df["Supply Pump 2 Power (KWh)"]/4 + df["Discharge Pump Power (KW)"]/4
Solar_energy = Total_usage_column.fillna(0)
Diesel_energy_column = Total_usage_column - Solar_energy
Total_cost_column = SOLAR_PRICE * Solar_energy + DIESEL_PRICE * Diesel_energy_column

df = pd.DataFrame(Total_cost_column.head(100))

fig = px.bar(df)
fig.update_xaxes(title_text='15 minutes interval')
fig.update_yaxes(title_text='Total Cost($)')

fig.write_image("./static/images/cost.png")
fig.show()




