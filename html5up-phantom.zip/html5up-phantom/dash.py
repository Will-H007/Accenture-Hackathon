import plotly.express as px
from plotly.subplots import make_subplots
import plotly.graph_objects as go
import pandas as pd
pd.options.plotting.backend = "plotly"
import matplotlib.pyplot as plt





data = pd.read_csv("historicalDataFrame.csv")
df = pd.DataFrame(data)


def Weathered(Weather):
    Weathered_column = df[df["Weather"] == Weather]
    return Weathered_column

# weathers = pd.Series(df["Weather"]).unique()

fig = make_subplots(rows=1, cols=2)

df = pd.DataFrame(df["Solar Generation (KW)"].head(100))
fig = df.plot.area()
fig.update_layout(height=600, width=800,
                  title_text= "Solar Generation")
fig.update_xaxes(title_text='15 minutes interval')
fig.update_yaxes(title_text='Solar Generation (KW)')

df2 = pd.DataFrame(df["Solar Generation (KW)"].head(100))
fig = df2.plot.area()
fig.update_layout(height=600, width=800,
                  title_text= "Solar Generation")
fig.update_xaxes(title_text='15 minutes interval')
fig.update_yaxes(title_text='Solar Generation (KW)')



fig.write_image("./static/images/dash.png")
fig.show()



