// Add images to the dashboard
var location = document.getElementById("Graphs");

for(let i = 0; i < 8; i++){
    var png = document.createElement("img");
    png.src = "./static/images/img" + i + ".png"
    location.appendChild(png);
}
