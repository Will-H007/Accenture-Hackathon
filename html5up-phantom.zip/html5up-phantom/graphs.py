import plotly.express as px
from base64 import b64encode
import io

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

index = 0
def generate_html(tag):
    fig = px.line(df, y=df[tag], x=df["Time"], title=tag)
    # fig.write_html("{}.html".format(tag))
    fig.write_image(f'./static/images/img{index}.png')




df = pd.read_csv('historicalDataFrame_Update_11_44am.csv')


# --- Special Tags
df["Flow in vs out (Ls-1)"] = df["Supply Pump 1 Flow Rate (l/s)"] + df["Supply Pump 2 Flow Rate (l/s)"] - df["Discharge Pump Flow Rate (l/s)"]
df["Solar Shortfalls (kW)"] = df["Current Solar Generation (KWh)"] - df["Current Power Usage (KWh)"]
df["Solar Shortfalls (kW)"] = df["Solar Shortfalls (kW)"].clip(upper=0)



tag_list = [
    "Tank Level (Kl)",
    "Current Solar Generation (KWh)",
    "Current Power Usage (KWh)",
    "Daily Solar Generation (KW)",
    "Daily Power From Grid (KW)",
    "Temperature (C)",
    "Flow in vs out (Ls-1)",
    "Solar Shortfalls (kW)"

    ]


df["Time"] = df["Day"] * 1 + df["Hour"] * 1 / 24 + df['Minutes'] * 1 / 24 / 60

for tag in tag_list:
    generate_html(tag)
    index = index + 1