import pandas as pd
import matplotlib.pyplot as plt
class Current_system:
    def __init__(self, file, DieselPrice = 1.4, SolarPrice = 0.2):
        self.file = file
        self.data = pd.read_csv(self.file)
        self.df = pd.DataFrame(data=self.data)

        # General Assumptions
        self.MAX_SOLAR_POWER = 72.8 #KiloWatts
        self.DIESEL_PRICE = DieselPrice
        self.SOLAR_PRICE = SolarPrice
        #Diesel Engine Assumptions
        self.DIESEL_CAPITAL = 35000
        self.DIESEL_LIFE = 5
        self.DIESEL_ENGINE_PRICE_PER_LITER = 2
        self.CONSUMPTION = 36
        self.DIESEL_POWER = 120
        self.DIESEL_ENGINE_PRICE_PER_HOUR = self.DIESEL_ENGINE_PRICE_PER_LITER * self.CONSUMPTION / self.DIESEL_POWER + self.DIESEL_CAPITAL/self.DIESEL_LIFE/365/24
        print(self.DIESEL_ENGINE_PRICE_PER_HOUR)
        #Solar Assumptions
        self.SOLAR_CAPITAL = 10000
        self.SOLAR_LIFE = 10
        self.SOLAR_SIZE = 7
        self.SOLAR_COST = self.SOLAR_CAPITAL/self.SOLAR_LIFE/self.SOLAR_SIZE/365/24
        print(self.SOLAR_COST)
        #Supply_Pumps
        self.supply_pump_1_power = self.df[self.df["Supply Pump 1 Power (KWh)"] != 0].drop_duplicates()["Supply Pump 1 Power (KWh)"].unique()[0]
        self.supply_pump_2_power = self.df[self.df["Supply Pump 2 Power (KWh)"] != 0].drop_duplicates()["Supply Pump 2 Power (KWh)"].unique()[0]

        self.pumping_cap1 = self.df[self.df["Supply Pump 1 Flow Rate (l/s)"] != 0].drop_duplicates()["Supply Pump 1 Flow Rate (l/s)"].unique()[0]
        self.pumping_cap2 = self.df[self.df["Supply Pump 2 Flow Rate (l/s)"] != 0].drop_duplicates()["Supply Pump 2 Flow Rate (l/s)"].unique()[0]

        self.dis_pump_power = self.df["Discharge Pump Power (KW)"].value_counts().keys()[0]
        self.dis_pump_cap = self.df["Discharge Pump Flow Rate (l/s)"].value_counts().keys()[0]
        self.pumping_cap1_per_hour = self.pumping_cap1 *60 * 60 / 1000
        self.pumping_cap2_per_hour = self.pumping_cap2 * 60 * 60 / 1000
        self.dis_pump_cap_per_hour = self.dis_pump_cap * 60 * 60 / 1000

        print(self.supply_pump_1_power)
        print(self.supply_pump_2_power)
        print(self.pumping_cap1)
        print(self.pumping_cap2)
        print(self.dis_pump_power)
        print(self.dis_pump_cap)

        print(self.Total_usage())
        print(self.Solar_energy())
        print(self.Diesel_energy())
        print(self.Total_cost().head(50))
    # def sunnyday(self,df,Sunny):
    #     if(Sunny):
    #         return df[df["Weather"] == "Sunny"]
    #     else:
    #         return df[df["Weather"] != "Sunny"]

    def Total_usage(self):
        self.Total_usage_column = self.df["Supply Pump 1 Power (KWh)"]/4 + self.df["Supply Pump 2 Power (KWh)"]/4 + self.df["Discharge Pump Power (KW)"]/4
        return self.Total_usage_column

    def Solar_energy(self):
        self.Solar_energy_column = self.Total_usage().fillna(0)
        # for i in range(len(self.Solar_energy_column)):
        #     if self.Total_usage()[i] <= self.df[" Solar Generation (KW)"][i]/4:
        #         self.Solar_energy_column[i] = self.Total_usage()[i]
        #     elif self.df[" Solar Generation (KW)"][i] == 0:
        #         self.Solar_energy_column[i] = 0
        #     else:
        #         self.Solar_energy_column[i] = self.df[" Solar Generation (KW)"][i]/4

        return self.Solar_energy_column

    def Diesel_energy(self):
        self.Diesel_energy_column = self.Total_usage() - self.Solar_energy()
        return self.Diesel_energy_column

    def Total_cost(self):
        self.Total_cost_column = self.SOLAR_PRICE * self.Solar_energy() + self.DIESEL_PRICE * self.Diesel_energy()
        return self.Total_cost_column

    def Tank_capacity(self):
        self.Tank_capacity_column = self.df["Discharge Pump Flow Rate (l/s)"]/4 + self.pumping_cap1/4 + self.pumping_cap2
        return self.Tank_capacity_column

    def Weathered(self, Weather):
        self.Weathered_column = self.df[self.df["Weather"] == Weather]
        return self.Weathered_column

    # def ploting(self):
    #     self.df = self.sunnyday(self.df, True)
    #     print(self.df["Temperature (C)"])
    #     plt.plot(self.df["Temperature (C)"])
    #     plt.savefig('images/Storage.png')
    #     plt.show()





