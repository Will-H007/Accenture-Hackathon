from algorithms import Current_system
import pandas as pd
import matplotlib.pyplot as plt
s = Current_system("historicalDataFrame.csv")
figure, axis = plt.subplots(2, 2)
axis[0, 0].plot(pd.Series(range(1,101)), s.df["Solar Generation (KW)"].head(100))
axis[0, 0].set_title("Solar Generation over a day", fontsize=7)
axis[0, 0].set_xlabel("15 minutes interval",fontsize=7)
axis[0, 0].set_ylabel("Solar Generation(KW)", fontsize=7)

axis[0, 1].plot(pd.Series(range(1,101)), s.df["Tank Level (Kl)"].head(100))
axis[0, 1].set_title("Tank Level over a day", fontsize=7)
axis[0, 1].set_xlabel("15 minutes interval",fontsize=7)
axis[0, 1].set_ylabel("Tank Level (Kl)", fontsize=7)

axis[1,0].plot(s.df["Supply Pump 1 Flow Rate (l/s)"].head(100), s.df["Supply Pump 2 Flow Rate (l/s)"].head(100))
figure.tight_layout(pad=4.0)
plt.savefig('static/images/Graphs.png')
plt.clf()
# plt.show()

s2 = Current_system("historicalDataFrame.csv")

plt.plot(pd.Series(range(1,101)), s.Total_cost().head(100))
plt.title("Total cost over time")
plt.xlabel("15 minutes interval")
plt.ylabel("Cost")
plt.savefig('static/images/BusinessGraphs.png')
plt.clf()
# plt.show()



