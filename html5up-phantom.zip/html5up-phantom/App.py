import win32api
from flask import Flask, render_template, redirect, url_for
from algorithms import Current_system
import pandas as pd

import matplotlib.pyplot as plt


app = Flask(__name__)
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')



@app.route('/cost')
def cost():
    return render_template('cost.html')

@app.route('/historical')
def historical():
    return render_template('historical.html')

if __name__ == "__main__":
    app.run(debug=True)